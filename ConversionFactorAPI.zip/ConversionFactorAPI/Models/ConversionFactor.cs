﻿using System;
using System.Collections.Generic;

namespace ConversionFactorAPI.Models;

public partial class ConversionFactor
{
    public int Id { get; set; }

    public string Category { get; set; } = null!;

    public string Unit { get; set; } = null!;

    public double Factor { get; set; }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ConversionFactorAPI.Models;

namespace ConversionFactorAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConversionFactorsController : ControllerBase
    {
        private readonly EmployeeDbContext _context;

        public ConversionFactorsController(EmployeeDbContext context)
        {
            _context = context;
        }

        // GET: api/ConversionFactors

        /// <summary>
        /// GET api/conversion/metricToImperial?value=10&metricUnit=m&imperialUnit=ft
        /// </summary>
        /// <param name="value"></param>
        /// <param name="metricUnit"></param>
        /// <param name="imperialUnit"></param>
        /// <returns></returns>
        [HttpGet("metricToImperial")]
        public double MetricToImperial(double value, string metricUnit, string imperialUnit)
        {
            var metricFactor = _context.ConversionFactors
                .Where(c => c.Category == "Length" && c.Unit == metricUnit)
                .Select(c => c.Factor)
                .FirstOrDefault();

            var imperialFactor = _context.ConversionFactors
                .Where(c => c.Category == "Length" && c.Unit == imperialUnit)
                .Select(c => c.Factor)
                .FirstOrDefault() / 3.2808; // convert feet to meters

            return value * metricFactor / imperialFactor;
        }


        /// <summary>
        //// GET api/conversion/imperialToMetric?value=10&imperialUnit=ft&metricUnit=m
        /// </summary>
        /// <param name="value"></param>
        /// <param name="imperialUnit"></param>
        /// <param name="metricUnit"></param>
        /// <returns></returns>
        [HttpGet("imperialToMetric")]
        public ActionResult<double> ImperialToMetric(double value, string imperialUnit, string metricUnit)
        {
            var imperialFactor = _context.ConversionFactors
                .Where(c => c.Category == "Length" && c.Unit == imperialUnit)
                .Select(c => c.Factor)
                .FirstOrDefault();

            var metricFactor = _context.ConversionFactors
                .Where(c => c.Category == "Length" && c.Unit == metricUnit)
                .Select(c => c.Factor)
                .FirstOrDefault() / 1.0936; // convert yards to meters

            return value * imperialFactor / metricFactor;
        }


    }
}
